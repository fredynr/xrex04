<div x-data="{
    showDrawerStudyTech: <?php if ((object) ('showDrawerStudyTech') instanceof \Livewire\WireDirective) : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('showDrawerStudyTech'->value()); ?>')<?php echo e('showDrawerStudyTech'->hasModifier('live') ? '.live' : ''); ?><?php else : ?>window.Livewire.find('<?php echo e($__livewire->getId()); ?>').entangle('<?php echo e('showDrawerStudyTech'); ?>')<?php endif; ?>,
}">
    <div class="flex bg-stone-50 rounded-sm shadow-md px-4 py-2">
        <div class="flex flex-col justify-around px-8 w-full">
            <div class="mb-2 text-gray-500">Solicitudes pendientes por realizar:</div>
            <div class="flex justify-between w-full">
                <div class="flex flex-col">
                    <div class="flex justify-center">
                        <span class="w-10 h-10 rounded-full bg-green-100 flex justify-center p-1">
                            <img src="<?php echo e(asset('images/clock.svg')); ?>">
                        </span>
                    </div>
                    <span class="text-sm">
                        <span class="text-[9px] text-gray-500 font-medium">PENDIENTES:</span>
                        <?php echo e($this->totalPendings); ?>

                    </span>
                </div>
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'flex flex-col p-2',
                    'bg-violet-50 rounded-lg border border-gray-300' => $currentTable === 'tables.table-pendings-to-do',
                ]); ?>">
                    <button wire:click="$dispatch('navigateTableTechnologist', ['tables.table-pendings-to-do']); $dispatch('cleanURL')"
                        class="flex flex-col cursor-pointer">
                        <div class="flex justify-center">
                            <span class="w-10 h-10 rounded-full bg-green-100 flex justify-center p-1">
                                <img src="<?php echo e(asset('images/stacks.svg')); ?>">
                            </span>
                        </div>
                        <span class="text-sm">
                            <span class="text-[9px] text-gray-500 font-medium">SOLICITUDES NUEVAS:</span>
                            <?php echo e($this->totalExams); ?>

                        </span>
                    </button>
                </div>
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'flex flex-col p-2',
                    'bg-violet-50 rounded-lg border border-gray-300' => $currentTable === 'tables.table-estudios-returned',
                ]); ?>">
                    <button wire:click="$dispatch('navigateTableTechnologist', ['tables.table-estudios-returned']); $dispatch('cleanURL')"
                        class="flex flex-col cursor-pointer">
                        <div class="flex justify-center">
                            <span class="w-10 h-10 rounded-full bg-green-100 flex justify-center p-1">
                                <img src="<?php echo e(asset('images/undo.svg')); ?>">
                            </span>
                        </div>
                        <span class="text-sm">
                            <span class="text-[9px] text-gray-500 font-medium">
                                ESTUDIOS DEVUELTOS:</span>
                            <?php echo e($this->totalDevueltos); ?>

                        </span>
                    </button>
                </div>
            </div>
        </div>
        <div class="flex items-center min-w-1/2">
            <label for="search" class="mb-2 text-sm font-medium text-gray-900 sr-only">Buscar</label>
            <div class="relative w-full">
                <div class="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
                    <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true"
                        xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                        <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z" />
                    </svg>
                </div>
                <input type="text"
                    wire:input.debounce.500ms="searchMapTable($event.target.value, '<?php echo e($currentTable); ?>')" id="search"
                    class="block w-full p-4 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500"
                    placeholder="Ingresa la busqueda..." />
            </div>
        </div>
    </div>
    <div class="bg-stone-50 mt-4">
        <!--[if BLOCK]><![endif]--><?php switch($currentTable):
            case ('tables.table-pendings-to-do'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('tables.table-pendings-to-do', ['search' => $search]);

$__html = app('livewire')->mount($__name, $__params, 'pendings-' . $search, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php break; ?>

            <?php case ('tables.table-estudios-returned'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('tables.table-estudios-returned', ['search' => $search]);

$__html = app('livewire')->mount($__name, $__params, $currentTable, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php break; ?>

            <?php default: ?>
                <div class="p-4 text-gray-500">Vista no encontrada!!!!!!!!!!!!!!!!!!!</div>
        <?php endswitch; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH C:\laravel\xrex04\resources\views/livewire/views/view-technologist.blade.php ENDPATH**/ ?>
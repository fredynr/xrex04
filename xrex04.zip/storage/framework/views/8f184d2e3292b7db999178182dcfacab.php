<div>
    <div class="flex bg-stone-50 rounded-sm shadow-md px-4 py-2">
        <div class="flex flex-col justify-around px-8 w-full">
            <div class="mb-2 text-gray-500">Estudios pendientes por lectura:</div>
            <div class="flex justify-between w-full">
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'flex flex-col p-2',
                    'bg-violet-50 rounded-lg border border-gray-300' => $currentTable === 'tables.table-pendings-to-read',
                ]); ?>">
                    <button wire:click="$dispatch('navigateTableSpecialist', ['tables.table-pendings-to-read']); $dispatch('cleanURL')"
                        class="flex flex-col cursor-pointer">
                        <div class="flex justify-center">
                            <span class="w-10 h-10 rounded-full bg-green-100 flex justify-center p-1">
                                <img src="<?php echo e(asset('images/clock.svg')); ?>">
                            </span>
                        </div>
                        <span class="text-sm">
                            <span class="text-[9px] text-gray-500 font-medium">PENDIENTES:</span>
                            <?php echo e($totalEstudios); ?>

                        </span>
                    </button>
                </div>
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'flex flex-col p-2',
                    'bg-violet-50 rounded-lg border border-gray-300' => $currentTable === 'tables.table-high-priority',
                ]); ?>">
                    <button wire:click="$dispatch('navigateTableSpecialist', ['tables.table-high-priority']); $dispatch('cleanURL')"
                        class="flex flex-col cursor-pointer">
                        <div class="flex justify-center">
                            <span class="w-10 h-10 rounded-full bg-green-100 flex justify-center p-1">
                                <img src="<?php echo e(asset('images/alertTriangle.svg')); ?>">
                            </span>
                        </div>
                        <span class="text-sm">
                            <span class="text-[9px] text-gray-500 font-medium">PRIORIDAD ALTA:</span>
                            <?php echo e($countAlta); ?>

                        </span>
                    </button>
                </div>
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'flex flex-col p-2',
                    'bg-violet-50 rounded-lg border border-gray-300' => $currentTable === 'tables.table-normal-priority',
                ]); ?>">
                    <button wire:click="$dispatch('navigateTableSpecialist', ['tables.table-normal-priority']); $dispatch('cleanURL')"
                        class="flex flex-col cursor-pointer">
                        <div class="flex justify-center">
                            <span class="w-10 h-10 rounded-full bg-green-100 flex justify-center p-1">
                                <img src="<?php echo e(asset('images/hand.svg')); ?>">
                            </span>
                        </div>
                        <span class="text-sm">
                            <span class="text-[9px] text-gray-500 font-medium">PRIORIDAD NORMAL:</span>
                            <?php echo e($countNormal); ?>

                        </span>
                    </button>
                </div>
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'flex flex-col p-2',
                    'bg-violet-50 rounded-lg border border-gray-300' => $currentTable === 'tables.table-low-priority',
                ]); ?>">
                    <button wire:click="$dispatch('navigateTableSpecialist', ['tables.table-low-priority']); $dispatch('cleanURL')"
                        class="flex flex-col cursor-pointer">
                        <div class="flex justify-center">
                            <span class="w-10 h-10 rounded-full bg-green-100 flex justify-center p-1">
                                <img src="<?php echo e(asset('images/flag.svg')); ?>">
                            </span>
                        </div>
                        <span class="text-sm">
                            <span class="text-[9px] text-gray-500 font-medium">PRIORIDAD BAJA:</span>
                            <?php echo e($countBaja); ?>

                        </span>
                    </button>
                </div>
                <div class="<?php echo \Illuminate\Support\Arr::toCssClasses([
                    'flex flex-col p-2',
                    'bg-violet-50 rounded-lg border border-gray-300' => $currentTable === 'tables.table-corrected',
                ]); ?>">
                    <button wire:click="$dispatch('navigateTableSpecialist', ['tables.table-corrected']); $dispatch('cleanURL')"
                        class="flex flex-col cursor-pointer">
                        <div class="flex justify-center">
                            <span class="w-10 h-10 rounded-full bg-green-100 flex justify-center p-1">
                                <img src="<?php echo e(asset('images/undo.svg')); ?>">
                            </span>
                        </div>
                        <span class="text-sm">
                            <span class="text-[9px] text-gray-500 font-medium">CORREGIDOS:</span>
                            <?php echo e($totalCorrected); ?>

                        </span>
                    </button>
                </div>

                <div class="flex items-center min-w-1/2">
                    <label for="search" class="mb-2 text-sm font-medium text-gray-900 sr-only">Buscar</label>
                    <div class="relative w-full">
                        <div class="absolute inset-y-0 start-0 flex items-center ps-3 pointer-events-none">
                            <svg class="w-4 h-4 text-gray-500 dark:text-gray-400" aria-hidden="true"
                                xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 20 20">
                                <path stroke="currentColor" stroke-linecap="round" stroke-linejoin="round"
                                    stroke-width="2" d="m19 19-4-4m0-7A7 7 0 1 1 1 8a7 7 0 0 1 14 0Z" />
                            </svg>
                        </div>
                        <input type="text"
                            wire:input.debounce.500ms="searchMapTable($event.target.value, '<?php echo e($currentTable); ?>')"
                            id="search"
                            class="block w-full p-4 ps-10 text-sm text-gray-900 border border-gray-300 rounded-lg bg-gray-50 focus:ring-blue-500 focus:border-blue-500"
                            placeholder="Ingresa la busqueda..." />
                    </div>
                </div>


            </div>
        </div>
    </div>
    <div class="bg-stone-50 mt-4">
        <!--[if BLOCK]><![endif]--><?php switch($currentTable):
            case ('tables.table-pendings-to-read'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('tables.table-pendings-to-read', ['search' => $search]);

$__html = app('livewire')->mount($__name, $__params, 'pendings-' . $search, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php break; ?>

            <?php case ('tables.table-high-priority'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('tables.table-high-priority', ['search' => $search]);

$__html = app('livewire')->mount($__name, $__params, 'high-' . $search, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php break; ?>

            <?php case ('tables.table-normal-priority'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('tables.table-normal-priority', ['search' => $search]);

$__html = app('livewire')->mount($__name, $__params, 'normal-' . $search, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php break; ?>

            <?php case ('tables.table-low-priority'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('tables.table-low-priority', ['search' => $search]);

$__html = app('livewire')->mount($__name, $__params, 'low-' . $search, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php break; ?>

            <?php case ('tables.table-corrected'): ?>
                <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('tables.table-corrected', ['search' => $search]);

$__html = app('livewire')->mount($__name, $__params, 'corrected-' . $search, $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
            <?php break; ?>

            <?php default: ?>
                <div class="p-4 text-gray-500">Vista tablas especialista no encontrada!!!!!!!!!!!!!!!!!!!</div>
        <?php endswitch; ?><!--[if ENDBLOCK]><![endif]-->
    </div>
</div>
<?php /**PATH C:\laravel\xrex04\resources\views/livewire/views/view-specialist.blade.php ENDPATH**/ ?>
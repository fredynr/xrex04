

<div x-data="{ mover: false, ancho: false, ocultar: false }" class="relative">
    <button @click="mover = !mover; ocultar = !ocultar; ancho = !ancho"
        class="rounded-full bg-cyan-500 absolute top-4 -right-3 cursor-pointer">
        <img src="<?php echo e(asset('images/doubleChevron.svg')); ?>" alt="">
    </button>
    <header class="min-h-34 p-4 flex justify-between items-center gap-x-2 bg-cyan-700 ">
        <a class="flex-none font-semibold text-xl text-white focus:outline-hidden focus:opacity-80 dark:text-white"
            href="#" aria-label="Brand"> <img 
            :src="mover ? '<?php echo e(asset('images/xLogo.png')); ?>' : '<?php echo e(asset('images/xrexLogo.png')); ?>'" 
            :width="mover ? 30 : 150" />
            <h2 x-show="!ocultar"><?php echo e(Auth::user()->name); ?></h2>
        </a>
    </header>
    <ul class="nav-left h-full bg-cyan-700 pt-4 transition-all duration-500" :class="ancho ? 'w-16' : 'w-64'">
        <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $menuItems; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menuItem): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li>
                <button
                    wire:click="$set('itemActivo', '<?php echo e($menuItem['label']); ?>'); $dispatch('navigateTo', ['<?php echo e($menuItem['navigate']); ?>'])"
                    class="w-full flex text-start items-center my-2 py-1 text-blue-50 px-2.5 text-sm rounded-l-lg cursor-pointer
                <?php echo e($itemActivo === $menuItem['label'] ? 'bg-stone-100 text-cyan-700' : 'text-blue-50 hover:text-cyan-700 hover:bg-sky-100'); ?>">
                    <span><img src="<?php echo e(asset($menuItem['icon'])); ?>" class="min-w-[26px]"></span>
                    <span class="ml-2 transition-transform duration-500" x-show="!ocultar"
                        :class="mover ? '-translate-x-44' : 'translate-x-0'">
                        <?php echo e($menuItem['label']); ?>

                    </span>
                </button>
            </li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
    </ul>
</div>
<?php /**PATH C:\laravel\xrex04\resources\views/livewire/components/sidebar.blade.php ENDPATH**/ ?>
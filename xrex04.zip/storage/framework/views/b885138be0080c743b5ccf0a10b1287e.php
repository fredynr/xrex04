

<?php $__env->startSection('content'); ?>
    <h4 style="padding: 1rem;">Visor DICOM (Proxy)</h4>

    <iframe src="<?php echo e($viewerUrl); ?>"
            width="100%" height="800px" frameborder="0"
            style="border: 1px solid #ccc; border-radius: 8px;">
    </iframe>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.visor', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laravel\xrex04\resources\views/viewer-proxy.blade.php ENDPATH**/ ?>
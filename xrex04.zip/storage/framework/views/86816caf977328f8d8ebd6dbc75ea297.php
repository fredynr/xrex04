<!--[if BLOCK]><![endif]--><?php if($paginator->hasPages()): ?>
    <nav role="navigation" aria-label="Pagination" class="flex justify-center mt-4">
        <ul class="inline-flex items-center space-x-1">
            
            <!--[if BLOCK]><![endif]--><?php if($paginator->onFirstPage()): ?>
                <li>
                    <span class="px-3 py-2 text-gray-400 bg-gray-100 border border-gray-300 rounded cursor-not-allowed">
                        &laquo;
                    </span>
                </li>
            <?php else: ?>
                <li>
                    <button wire:click="previousPage('<?php echo e($paginator->getPageName()); ?>')" class="px-3 py-2 text-gray-700 bg-white border border-gray-300 rounded hover:bg-blue-100 hover:text-blue-700 cursor-pointer">
                        &laquo;
                    </button>
                </li>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

            
            <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $elements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $element): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                
                <!--[if BLOCK]><![endif]--><?php if(is_string($element)): ?>
                    <li>
                        <span class="px-3 py-2 text-gray-500">...</span>
                    </li>
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->

                
                <!--[if BLOCK]><![endif]--><?php if(is_array($element)): ?>
                    <!--[if BLOCK]><![endif]--><?php $__currentLoopData = $element; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $page => $url): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <!--[if BLOCK]><![endif]--><?php if($page == $paginator->currentPage()): ?>
                            <li>
                                <span class="px-3 py-2 text-white bg-blue-600 border border-blue-600 rounded font-bold cursor-default">
                                    <?php echo e($page); ?>

                                </span>
                            </li>
                        <?php else: ?>
                            <li>
                                <button wire:click="gotoPage(<?php echo e($page); ?>, '<?php echo e($paginator->getPageName()); ?>')" class="px-3 py-2 text-gray-700 bg-white border border-gray-300 rounded hover:bg-blue-100 hover:text-blue-700 cursor-pointer">
                                    <?php echo e($page); ?>

                                </button>
                            </li>
                        <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->
                <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><!--[if ENDBLOCK]><![endif]-->

            
            <!--[if BLOCK]><![endif]--><?php if($paginator->hasMorePages()): ?>
                <li>
                    <button wire:click="nextPage('<?php echo e($paginator->getPageName()); ?>')" class="px-3 py-2 text-gray-700 bg-white border border-gray-300 rounded hover:bg-blue-100 hover:text-blue-700 cursor-pointer">
                        &raquo;
                    </button>
                </li>
            <?php else: ?>
                <li>
                    <span class="px-3 py-2 text-gray-400 bg-gray-100 border border-gray-300 rounded cursor-not-allowed">
                        &raquo;
                    </span>
                </li>
            <?php endif; ?><!--[if ENDBLOCK]><![endif]-->
        </ul>
    </nav>
<?php endif; ?><!--[if ENDBLOCK]><![endif]--><?php /**PATH C:\laravel\xrex04\resources\views/vendor/livewire/custom-pagination.blade.php ENDPATH**/ ?>
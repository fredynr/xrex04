<!DOCTYPE html>
<html lang="<?php echo e(str_replace('_', '-', app()->getLocale())); ?>">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">

    <style>
        [x-cloak] {
            display: none;
        }

        .nav-left img {
            filter: invert(100%);
        }

        .nav-left>li:hover img {
            filter: none;
        }
    </style>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
        <?php
        $__assetKey = '3152569751-0';

        ob_start();
    ?>
    <?php echo $__env->yieldContent('head'); ?>
</head>

<body class="bg-stone-100">
    <div>
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('app-layout');

$__html = app('livewire')->mount($__name, $__params, 'lw-3152569751-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
    </div>
</body>
<script>
    document.addEventListener('navigateTo', () => {
        // Limpia la URL
        const cleanURL = window.location.origin + window.location.pathname;
        history.replaceState(null, '', cleanURL);
        // Reinicia la paginación en el componente Livewire
        Livewire.dispatch('resetPagination');
    });

    document.addEventListener('cleanURL', () => {
        // Limpia la URL
        const cleanURL = window.location.origin + window.location.pathname;
        history.replaceState(null, '', cleanURL);
        Livewire.dispatch('resetPagination');
    });


    document.addEventListener('alpine:init', () => {
        Alpine.store('columnToggle', {
            columns: JSON.parse(localStorage.getItem('columns')) || {
                showFecha: true,
                showIdentificacion: true,
                showProcedencia: false
            },

            // Método para alternar y guardar el estado
            toggleColumn(columnName) {
                this.columns[columnName] = !this.columns[columnName];
                localStorage.setItem('columns', JSON.stringify(this.columns));
            }
        });
    });
</script>

</html>
<?php /**PATH C:\laravel\xrex04\resources\views/layouts/layout-tales.blade.php ENDPATH**/ ?>
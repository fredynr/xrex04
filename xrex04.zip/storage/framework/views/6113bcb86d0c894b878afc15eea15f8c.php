<div>
    estoy en drawwer 
</div><?php /**PATH C:\laravel\xrex04\resources\views/components/drawer-i-return.blade.php ENDPATH**/ ?>
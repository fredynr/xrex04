<div>
    Lorem ipsum dolor sit amet.
</div>
<?php /**PATH C:\laravel\xrex04\resources\views/livewire/views/technologist.blade.php ENDPATH**/ ?>
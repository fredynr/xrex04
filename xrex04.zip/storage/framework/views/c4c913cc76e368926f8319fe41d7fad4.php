<div>
    <div class="flex h-screen">
        <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('components.sidebar');

$__html = app('livewire')->mount($__name, $__params, 'lw-4171919903-0', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>

        <div class="flex-1">
            <!--[if BLOCK]><![endif]--><?php switch($currentView):
                case ('views.view-specialist'): ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('views.view-specialist');

$__html = app('livewire')->mount($__name, $__params, 'lw-4171919903-1', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php break; ?>

                <?php case ('views.view-technologist'): ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('views.view-technologist');

$__html = app('livewire')->mount($__name, $__params, 'lw-4171919903-2', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php break; ?>

                <?php case ('tables.table-estudios-returned'): ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('tables.table-estudios-returnes');

$__html = app('livewire')->mount($__name, $__params, 'lw-4171919903-3', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php break; ?>

                <?php case ('tables.table-template'): ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('tables.table-template');

$__html = app('livewire')->mount($__name, $__params, 'lw-4171919903-4', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php break; ?>

                <?php case ('tables.table-delivery-estudio'): ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('tables.table-delivery-estudio');

$__html = app('livewire')->mount($__name, $__params, 'lw-4171919903-5', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php break; ?>

                <?php case ('views.view-transcriber'): ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('views.view-transcriber');

$__html = app('livewire')->mount($__name, $__params, 'lw-4171919903-6', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php break; ?>

                <?php case ('views.view-approve'): ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('views.view-approve');

$__html = app('livewire')->mount($__name, $__params, 'lw-4171919903-7', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php break; ?>

                <?php case ('views.view-prueba'): ?>
                    <?php
$__split = function ($name, $params = []) {
    return [$name, $params];
};
[$__name, $__params] = $__split('views.view-prueba');

$__html = app('livewire')->mount($__name, $__params, 'lw-4171919903-8', $__slots ?? [], get_defined_vars());

echo $__html;

unset($__html);
unset($__name);
unset($__params);
unset($__split);
if (isset($__slots)) unset($__slots);
?>
                <?php break; ?>

                <?php default: ?>
                    <div class="p-4 text-gray-500">Vista no encontrada</div>
            <?php endswitch; ?><!--[if ENDBLOCK]><![endif]-->
        </div>
    </div>

    <!-- Toast Component -->
    
    <div x-data="toastComponent()" x-init="init()" x-show="visible"
        x-transition:enter="transition ease-out duration-300" x-transition:enter-start="opacity-0 translate-y-2"
        x-transition:enter-end="opacity-100 translate-y-0" x-transition:leave="transition ease-in duration-300"
        x-transition:leave-start="opacity-100 translate-y-0" x-transition:leave-end="opacity-0 translate-y-2"
        class="fixed bottom-4 right-4 bg-gray-800 text-white px-4 py-3 rounded shadow-lg z-50 flex items-start gap-4"
        style="display: none;">
        <span x-text="text" class="flex-1"></span>
        <button @click="visible = false"
            class="text-white hover:text-gray-300 font-bold text-lg leading-none">&times;</button>
    </div>

    <script>
        window.addEventListener('toast', e => {
            console.log('Toast recibido:', e.detail);
        });

        function toastComponent() {
            return {
                visible: false,
                text: '',
                timeoutId: null,
                init() {
                    window.addEventListener('toast', e => {
                        this.text = e.detail.message || 'Notificación';
                        this.visible = true;

                        // Clear any previous timeout
                        if (this.timeoutId) clearTimeout(this.timeoutId);

                        // Set new timeout (default to 60s if not provided)
                        this.timeoutId = setTimeout(() => this.visible = false, e.detail.duration || 60000);
                    });
                }
            }
        }
    </script>

</div>
<?php /**PATH C:\laravel\xrex04\resources\views/livewire/app-layout.blade.php ENDPATH**/ ?>
import voiceRecorder from './voiceRecorder';
window.voiceRecorder = voiceRecorder;
